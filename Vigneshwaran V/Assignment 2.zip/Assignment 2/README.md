# Step 1

```bash
pip install flask
```

# Step 2

```bash
flask run
```
